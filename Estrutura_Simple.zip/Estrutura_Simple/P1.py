import PySimpleGUI as sg
import Struct
import ListaDinamica
import pandas as pd
import random

class janela1():
    def __init__(self):
        layout1 = [ [sg.Button('Ver dados')],
                    [sg.Button('Exportar para arquivo de texto')],
                    [sg.Button('Voltar')] ]

        win1 = sg.Window('Lista', layout1)
        win1tel_active = False

        while True:
            event, value = win1.read()

            if (event == 'Ver dados'):
                estrutura = ListaDinamica.CoviList()
                data = pd.read_csv("./covid_19_data.csv", header=1, na_filter=True, na_values='nan', keep_default_na=False)
                aux = list(range(len(data)))
                random.shuffle(aux)
                x = 0

                while (x < 100):
                    dado = Struct.CovidLine(*data.loc[aux[x]])
                    estrutura.inserir(dado)
                    x += 1

            elif (event == 'Voltar'):
                win1.close()
                main = main.Main()

            elif(event == sg.WIN_CLOSED):
                break
